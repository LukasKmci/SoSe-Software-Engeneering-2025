# punkt vor datei weil im selbem ordner
from .my_functions import estimate_max_hr, build_person, build_experiment
